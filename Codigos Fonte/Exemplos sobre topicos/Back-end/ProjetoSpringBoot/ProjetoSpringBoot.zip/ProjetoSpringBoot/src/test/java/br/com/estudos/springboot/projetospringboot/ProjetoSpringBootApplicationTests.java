package br.com.estudos.springboot.projetospringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
